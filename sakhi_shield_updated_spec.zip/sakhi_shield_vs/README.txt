SAKHI Shield — Updated connected frontend prototype

Run:
1. Extract this ZIP.
2. Open the sakhi_shield_vs folder in VS Code.
3. Install the Live Server extension if needed.
4. Right-click index.html and choose Open with Live Server.

Included screens:
- Welcome/login and setup
- Home dashboard
- Smart SOS demo
- Safe Journey with check-in, extend, stop, SOS link and location snapshot
- Digital Shield message/link rule checker
- Shared Trusted Contacts
- Help & Helplines and harassment evidence guide
- Profile & Privacy settings and SMS draft option

Important limitations:
- This is a frontend-only prototype. LocalStorage is not secure production storage.
- There is no backend scheduler, so missed check-ins cannot run when the app is closed.
- It does not send SMS or automatic alerts. SMS fallback only opens a draft for the user to send.
- Location is a one-time snapshot when requested, not continuous/background live tracking.
- The contact-viewing page for an authenticated trusted contact and server-side access control still require backend implementation.
- Rule-based message/link checks can miss threats or flag harmless content; no result guarantees safety.
- India helpline details and service availability can change; verify before relying on them.
